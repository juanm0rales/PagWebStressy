<header>
<div style="background-color: white">
  <a href="/web/index.html" ><img src="https://1.bp.blogspot.com/-ERcM3lTqMjs/YGYQmgg-5GI/AAAAAAAApMo/sR3TikAufXI7UYyJAeKPP6_p40mgNrtmgCLcBGAsYHQ/s456/Stressy_logo_1_b_corto.jpg" alt="Logo Stressy" width="248" height="86"> </a> 
</div>
</header>
